class Config:
    SECRET_KEY = 'supersecret'