from flask import request, jsonify, session
from flask_login import login_required
from utils.auth import rbac
from tasks.async_tasks import run_async_task

@login_required
@rbac("admin")
def handle_task():
    data = request.json
    task_type = data.get("task_type")
    task = run_async_task.delay(task_type, data)
    return jsonify({"task_id": task.id, "status": "Processing"})