from flask import request, jsonify, session
from flask_login import login_user, logout_user, UserMixin
from app import login_manager

users = {"admin": "password"}

class User(UserMixin):
    def __init__(self, id):
        self.id = id

@login_manager.user_loader
def load_user(user_id):
    return User(user_id) if user_id in users else None

def login():
    data = request.json
    username, password = data.get('username'), data.get('password')
    if users.get(username) == password:
        user = User(username)
        login_user(user)
        session['user_id'] = username
        session['role'] = 'admin'
        return jsonify({"status": "success"})
    return jsonify({"status": "fail", "message": "Invalid credentials"}), 401

def logout():
    logout_user()
    return jsonify({"status": "success"})