from celery import shared_task

@shared_task
def run_async_task(task_type, data):
    return {"result": f"Handled {task_type}"}