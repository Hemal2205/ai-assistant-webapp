from functools import wraps
from flask import session, jsonify

def rbac(role):
    def wrapper(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if session.get('role') != role:
                return jsonify({'error': 'Access Denied'}), 403
            return f(*args, **kwargs)
        return decorated
    return wrapper